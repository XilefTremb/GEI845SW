/*

Code for GEI744, ROS and Darwin_Op robotic plateform.
Author: Guillaume Durandau, Guillaume.Durandau@Usherbrooke.ca
License: BSD

Vers: 0.0.1
Date: 04/02/14

*/

#include "darwin_control/DarwinJointControl.h"

DarwinJointControl::DarwinJointControl(std::shared_ptr<rclcpp::Node> node, double rate) : node_(node), rate_(rate)
{
	bool init_joint = false;
	bool temp = true;

	auto parameters_client = std::make_shared<rclcpp::SyncParametersClient>(node_, "joint_state_broadcaster");
	while (!parameters_client->wait_for_service(1s)) {
		rclcpp::spin_some(node_);
		if (!rclcpp::ok()) {
			RCLCPP_ERROR(node_->get_logger(), "Interrupted while waiting for the service. Exiting.");
			rclcpp::shutdown();
		}
		RCLCPP_INFO(node_->get_logger(), "service not available, waiting again...");
	}

	std::vector<rclcpp::Parameter> parameters = parameters_client->get_parameters({"joints"});

	// std::vector<std::string> joints_list;
	std::vector<std::string> list_joint_name = parameters[0].as_string_array();

	for (uint i = 0; i < list_joint_name.size(); ++i)
	{
		joint_map_[static_cast<std::string>(list_joint_name[i])] = new DarwinJoint(static_cast<std::string>(list_joint_name[i]), node_, rate);
	}

	std::map<std::string, DarwinJoint*>::iterator it;
	while (rclcpp::ok())
	{
		for(it = joint_map_.begin(); it != joint_map_.end(); ++it)
		{
			temp = temp and it->second->initEnd();
			rclcpp::spin_some(node_);
			if(!it->second->initEnd())
				RCLCPP_INFO(node_->get_logger(), "%s", it->second->getName().c_str());
		}
		!temp ? temp = true : init_joint = true ;
				
		if(init_joint)
		{
			break;
			RCLCPP_INFO(node_->get_logger(), "Initialisation end");
		}
	}
}

double DarwinJointControl::getJoint(std::string joint_name)
{
	std::map<std::string, DarwinJoint*>::iterator it;
	it = joint_map_.find(joint_name);

	if(it != joint_map_.end())
		return it->second->getJoint();
	else
	{
		RCLCPP_ERROR(node_->get_logger(), "Joint name not found !");
		return 0;
	}
}

void DarwinJointControl::setJoint(std::string joint_name, double joint_send_value)
{
	std::map<std::string, DarwinJoint*>::iterator it;
	it = joint_map_.find(joint_name);
	if(it != joint_map_.end())
		it->second->setJoint(joint_send_value);
	else
		RCLCPP_ERROR(node_->get_logger(), "joint name not found !");
}

void DarwinJointControl::goalPos(std::string joint_name, double joint_send_value, rclcpp::Duration timeTot)
{
	joint_map_[joint_name]->goalPos(joint_send_value, timeTot);
}

void DarwinJointControl::getNameOnScreen()
{
	std::map<std::string, DarwinJoint*>::iterator it;
	for(it = joint_map_.begin(); it != joint_map_.end(); ++it)
		RCLCPP_INFO(node_->get_logger(),"Joint: %s", it->first.c_str());
}
