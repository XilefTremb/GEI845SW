/*

Code for GEI744, ROS and Darwin_Op robotic plateform.
Author: Guillaume Durandau, Guillaume.Durandau@Usherbrooke.ca
License: BSD

Vers: 0.0.1
Date: 04/02/14

*/

#include "darwin_control/DarwinJoint.h"
using std::placeholders::_1;

DarwinJoint::DarwinJoint(std::string joint_name, std::shared_ptr<rclcpp::Node> node, double rate) : node_(node), rate_(rate)
{
	darwin_joint_name_.assign(joint_name);
	std::ostringstream joint_name_command_;
	
	joint_name_command_ << "/" << darwin_joint_name_.c_str() << "_position_controller/commands";
	
	stop_thread_ = false;
	first_msg = false;

	joint_pub_ = node_->create_publisher<std_msgs::msg::Float64MultiArray>(
    joint_name_command_.str().c_str(), 1);
	joint_sub_ = node_->create_subscription<sensor_msgs::msg::JointState>("/joint_states", 1,	std::bind(&DarwinJoint::darwinCallback, this, _1));
}

DarwinJoint::~DarwinJoint()
{
	// mutex_.lock();
	stop_thread_ = true;
	// mutex_.unlock();
}

double DarwinJoint::getJoint()
{
	return joint_value_;
}

std::string DarwinJoint::getName()
{
	return darwin_joint_name_.c_str();
}

void DarwinJoint::setJoint(double joint_send_value)
{
	// mutex_.lock();
	send_value_ = joint_send_value;
	// mutex_.unlock();
	RCLCPP_INFO(node_->get_logger(),"Joint %s just sent: %f", darwin_joint_name_.c_str(), joint_send_value);
}

bool DarwinJoint::initEnd()
{
	return first_msg;
}

// void DarwinJoint::darwinCallback(const control_msgs::msg::JointControllerState::ConstPtr& msg_in)
// {
// 	joint_value_ = msg_in->set_point;
// 	if(!first_msg)
// 	{
// 		send_value_ = joint_value_;
// 		thread_pub_ = new boost::thread(&DarwinJoint::pubThread, this);
// 		first_msg = true;
// 		RCLCPP_DEBUG(node_->get_logger(), "Start thread");
// 	}
// }
void DarwinJoint::darwinCallback(sensor_msgs::msg::JointState::SharedPtr msg_in)
{
	size_t index = std::distance(msg_in->name.begin(), std::find(msg_in->name.begin(), msg_in->name.end(), darwin_joint_name_));
	joint_value_ = msg_in->position[index];
	if(!first_msg)
	{
		send_value_ = joint_value_;
		thread_pub_ = new boost::thread(&DarwinJoint::pubThread, this);
		first_msg = true;
		RCLCPP_INFO(node_->get_logger(), "Start thread");
	}
}

void DarwinJoint::pubThread()
{
	bool kill_me = false;
	msg_out_.data.push_back(0);
	rclcpp::Rate r(rate_);
	while (rclcpp::ok())
	{
		//mutex_.lock();
		msg_out_.data[0] = send_value_;
		kill_me = stop_thread_;
		//mutex_.unlock();
	
		joint_pub_->publish(msg_out_);
		r.sleep();
		
		if(kill_me)
			break;
	}
}

void DarwinJoint::goalPos(double j_val, rclcpp::Duration tf)
{
	thread_goal_ = new boost::thread(&DarwinJoint::goalPosThread, this, j_val, tf);
}

void DarwinJoint::goalPosThread(double j_fin, rclcpp::Duration tf)
{
    rclcpp::Time now = node_->get_clock()->now();
    rclcpp::Time t_init = node_->get_clock()->now();
    rclcpp::Rate loop_rate(rate_);

    double j_init = getJoint();
    RCLCPP_INFO(node_->get_logger(), "Joint pos: %f", j_init);
    RCLCPP_INFO(node_->get_logger(), "Joint des pos: %f", j_fin);
    RCLCPP_INFO(node_->get_logger(), "tf: %f", tf.seconds());
    double val;
    double a2 = (3 / pow(tf.seconds(), 2)) * (j_fin - j_init);
    RCLCPP_INFO(node_->get_logger(), "a2: %f", a2);
    double a3 = - (2 / pow(tf.seconds(), 3)) * (j_fin - j_init);
    RCLCPP_INFO(node_->get_logger(), "a3: %f", a3);
    RCLCPP_INFO(node_->get_logger(), "a4: %f", pow((node_->get_clock()->now().seconds() - t_init.seconds()), 2));
	while(rclcpp::ok())
	{
		val = j_init + a2 * pow((node_->get_clock()->now().seconds() - t_init.seconds()), 2) + a3 * pow((node_->get_clock()->now().seconds() - t_init.seconds()), 3); // extrapolation cubique
		setJoint(val);
		if((node_->get_clock()->now().seconds() - t_init.seconds() ) >= tf.seconds()) 
			break;
		loop_rate.sleep();
	}
}

