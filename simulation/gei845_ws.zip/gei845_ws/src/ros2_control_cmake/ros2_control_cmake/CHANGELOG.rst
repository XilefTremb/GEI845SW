^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ros2_control_cmake
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.0 (2026-04-28)
------------------
* Default to C++20 if available (`#30 <https://github.com/ros-controls/ros2_control_cmake/issues/30>`_)
* Contributors: Christoph Fröhlich

0.3.0 (2025-10-02)
------------------
* Update compiler options (`#15 <https://github.com/ros-controls/ros2_control_cmake/issues/15>`_)
* Contributors: Christoph Fröhlich

0.2.1 (2025-06-06)
------------------
* Bump CMake minimum version (`#8 <https://github.com/ros-controls/ros2_control_cmake/issues/8>`_)
* Contributors: mosfet80

0.2.0 (2025-05-25)
------------------
* Add compiler standards (`#7 <https://github.com/ros-controls/ros2_control_cmake/issues/7>`_)
* Contributors: Christoph Fröhlich

0.1.1 (2025-03-26)
------------------
* Touch up the repo (`#4 <https://github.com/ros-controls/ros2_control_cmake/issues/4>`_)
* Contributors: Christoph Fröhlich

0.1.0 (2025-02-28)
------------------
* Add cmake package (`#1 <https://github.com/ros-controls/ros2_control_cmake/issues/1>`_)
* Contributors: Christoph Froehlich
